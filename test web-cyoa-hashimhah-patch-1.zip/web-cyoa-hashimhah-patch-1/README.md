# web-cyoa-levels
Web-Based CYOA using Arrays to Define Levels
Adventure Planner Google Sheet URL: 
https://docs.google.com/spreadsheets/d/1-HPjDUlCPRp8DBsYLP08yaWrj2WFL-0JJxIUsnC-gfY/edit?usp=sharing
Story Text
https://docs.google.com/document/d/1UNiqG-16rn0qV_6IxWnONaWmx0548ut9fpK5e2xVoXY/edit
